package org.epsi.math;

public class Algo {



}
