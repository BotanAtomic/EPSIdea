<?php
 
$linkBDD = mysqli_connect("localhost", "root", "rootroot", "EPSI_DA");
//Check connexion BDD
    if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: </br>".mysqli_connect_error();
  } else {
  echo "Nice ça marche, c'est connecté :-) </br>";
  }
  
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_NUMBER_INT);
$surname = filter_input(INPUT_POST, 'surname', FILTER_SANITIZE_STRING);
$user_name = filter_input(INPUT_POST, 'user_name', FILTER_SANITIZE_SPECIAL_CHARS);
$address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
$verifpassword = filter_input(INPUT_POST, 'verifpassword', FILTER_SANITIZE_STRING);


// Check password 
if($verifpassword !== $password) {
    die('Mots de passe différents');
}

    // Check si email est unique 
    $reqSelectMail = "SELECT email from user";
    $resSelectMail = mysqli_query($linkBDD, $reqSelectMail);
    $row = mysqli_fetch_all($resSelectMail, MYSQLI_ASSOC);
    foreach ($row as $BDDemail) {
    if ($email == $BDDemail['email']){
            echo "erreur, email is not valable"; 
            exit;
   }
   }
    
    // Requete SQL inscription 
    $reqInsert = 'INSERT INTO user (name, surname, user_name, address, email, password) VALUES ';
    $reqInsert .= '("'.$name.'","'.$surname.'","'.$address.'","'.$email.'","'.$password.'")';
    
    $resInsert = mysqli_query($linkBDD, $reqInsert);
    // Vérification de problème éventuel
    if(mysqli_errno($linkBDD)) {
    die(mysqli_error($linkBDD));
    } else {
    echo "Inscription réussie";
    }

        // Récupération de la dernière clef primaire insérée
            echo 'Enregistrement '.mysqli_insert_id($linkBDD).' bien créé :-)';
            
?>
  <script>
    $(function(){
        $("#verif").submit(function(event){
            var name        = $("#name").val();
            var surname     = $("#surname").val();
            var user_name   = $("#user_name").val();
            var address     = $("#address").val();
            var email       = $("#email").val();
            var password    = $("#password").val();
            var dataString = name + surname + user_name + address + email + password;
            var msg_all    = "Merci de remplir tous les champs";
            var msg_alert  = "Merci de remplir ce champs";

            if (dataString  === "") {
                $("#msg_all").html(msg_all);
            } else if (name === "") {
                $("#msg_name").html(msg_alert);
            } else if (surname === "") {
                $("#msg_surname").html(msg_alert);
            } else if (email === "") {
                $("#msg_email").html(msg_alert);
            } else if (address === "") {
                $("#msg_address").html(msg_alert);
            } else if (password === "") {
                $("#msg_password").html(msg_alert);
            } else if (user_name === "") {
                $("#msg_user_name").html(msg_alert);
            } else {
                $.ajax({
                    type : "POST",
                    url: $(this).attr("action"),
                    data: $(this).serialize(),
                    success : function() {
                        $("#verif").html("<p>Formulaire bien envoyé</p>");
                    },
                    error: function() {
                        $("#verif").html("<p>Erreur d'appel, le formulaire ne peut pas fonctionner</p>");
                    }
                });
            }

            return false;
        });
    });
</script>


