<form action="room.php" method="POST">
    <p><input type="text" required name="name" placeholder="nom du module"></p>
    <p><input type="file" required name="image_module" placeholder="choisir une image representative du module"></p>
    <input type="submit">
</form>

<script>
    $(function(){
        $("#verif").submit(function(event){
            var name_department = $("#name").val();
            var image_department = $("#image_module").val();
            var dataString = name_module + image_module;
            var msg_all    = "Merci de remplir tous les champs";
            var msg_alert  = "Merci de remplir ce champs";
            
            if (dataString === "") {
                $("#msg_all").html(msg_all);
            }else if (image_module === ""){
                $("#msg_alert").html(msg_alert);
            } else if (name_module === ""){
                $("#msg_alert").html(msg_alert);
            } else { 
               $.ajax({
                    type : "POST",
                    url: $(this).attr("action"),
                    data: $(this).serialize(),
                    success : function() {
                        $("#verif").html("<p>Formulaire bien envoyé</p>");
                    },
                    error: function() {
                        $("#verif").html("<p>Erreur d'appel, le formulaire ne peut pas fonctionner</p>");
                    }
                }); 
                }
</script>

<?php
 
$linkBDD = mysqli_connect("localhost", "root", "rootroot", "EPSI_DA");
//Check connexion BDD
    if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: </br>".mysqli_connect_error();
  } else {
  echo "Nice ça marche, c'est connecté :-) </br>";
  }
  
$name_module = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
//$image_module = filter_input(INPUT_POST, 'image_module', FILTER_SANITIZE_SPECIAL_CHARS);


    // Check si nom_module est unique 
    $reqSelectNM = "SELECT name from module ";
    $resSelectNM = mysqli_query($linkBDD, $reqSelectNM);
    $row = mysqli_fetch_all($resSelectNM, MYSQLI_ASSOC);
    foreach ($row as $BDDname) {
    if ($name_module == $BDDname['name']){
            echo "erreur, name is not valable"; 
            exit;
   }
   }
    
    // Requete SQL inscription 
    $reqInsert = 'INSERT INTO module (name)VALUES ';
    $reqInsert .= '("'.$name.'")';
    
    $resInsert = mysqli_query($linkBDD, $reqInsert);
    // Vérification de problème éventuel
    if(mysqli_errno($linkBDD)) {
    die(mysqli_error($linkBDD));
    } else {
    echo "Inscription réussie";
    }

        // Récupération de la dernière clef primaire insérée
            echo 'Enregistrement '.mysqli_insert_id($linkBDD).' bien créé :-)';
?>